$ErrorActionPreference = 'Stop'
$GradleVersion = '8.13'
$ToolsDir = Join-Path $env:LOCALAPPDATA 'DocPilotTools'
$GradleHome = Join-Path $ToolsDir "gradle-$GradleVersion"
$ZipPath = Join-Path $ToolsDir "gradle-$GradleVersion-bin.zip"

New-Item -ItemType Directory -Force -Path $ToolsDir | Out-Null

# Prefer Android Studio's bundled JDK 17 if JAVA_HOME is not already configured.
if (-not $env:JAVA_HOME) {
    $JdkCandidates = @(
        'C:\Program Files\Android\Android Studio\jbr',
        (Join-Path $env:LOCALAPPDATA 'Programs\Android Studio\jbr')
    )
    foreach ($Candidate in $JdkCandidates) {
        if (Test-Path (Join-Path $Candidate 'bin\java.exe')) {
            $env:JAVA_HOME = $Candidate
            break
        }
    }
}
if (-not $env:JAVA_HOME) {
    $JavaCommand = Get-Command java -ErrorAction SilentlyContinue
    if ($JavaCommand) { $env:JAVA_HOME = Split-Path (Split-Path $JavaCommand.Source -Parent) -Parent }
}

# Add local.properties if the default Android SDK location exists.
$SdkPath = Join-Path $env:LOCALAPPDATA 'Android\Sdk'
$LocalProperties = Join-Path $PSScriptRoot 'local.properties'
if (-not (Test-Path $LocalProperties) -and (Test-Path $SdkPath)) {
    $EscapedSdkPath = $SdkPath.Replace('\', '\\').Replace(':', '\:')
    Set-Content -Path $LocalProperties -Value "sdk.dir=$EscapedSdkPath" -Encoding ASCII
}

if (-not (Test-Path (Join-Path $GradleHome 'bin/gradle.bat'))) {
    Write-Host "Downloading Gradle $GradleVersion..."
    $Url = "https://services.gradle.org/distributions/gradle-$GradleVersion-bin.zip"
    Invoke-WebRequest -Uri $Url -OutFile $ZipPath
    Expand-Archive -Path $ZipPath -DestinationPath $ToolsDir -Force
    Remove-Item $ZipPath -Force
}

$Gradle = Join-Path $GradleHome 'bin/gradle.bat'
& $Gradle --version
Write-Host 'Building debug APK...'
& $Gradle --no-daemon :app:assembleDebug
if ($LASTEXITCODE -ne 0) { throw 'Gradle build failed. See the messages above.' }

$Apk = Join-Path $PSScriptRoot 'app/build/outputs/apk/debug/app-debug.apk'
Write-Host "Build succeeded: $Apk" -ForegroundColor Green
