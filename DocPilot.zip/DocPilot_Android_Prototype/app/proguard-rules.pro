# PDFBox-Android includes consumer rules in its published artifact.
# Add app-specific keep rules here only when release testing identifies a need.
