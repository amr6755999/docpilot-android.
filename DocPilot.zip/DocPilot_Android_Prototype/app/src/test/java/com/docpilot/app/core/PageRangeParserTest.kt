package com.docpilot.app.core

import org.junit.Assert.assertEquals
import org.junit.Test

class PageRangeParserTest {
    @Test
    fun parsesSinglePagesAndRangesWithoutDuplicates() {
        assertEquals(listOf(0, 1, 2, 4), PageRangeParser.parse("1-3,5,2", 5))
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsOutOfRangePage() {
        PageRangeParser.parse("1-6", 5)
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsDescendingRange() {
        PageRangeParser.parse("4-2", 5)
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsEmptyRange() {
        PageRangeParser.parse(" , ", 5)
    }
}
