package com.docpilot.app.core

/** Converts page expressions such as "1-3,5" to zero-based page indexes. */
object PageRangeParser {
    fun parse(input: String, pageCount: Int): List<Int> {
        require(pageCount > 0) { "The PDF has no pages." }
        val result = linkedSetOf<Int>()
        val tokens = input.split(',').map { it.trim() }.filter { it.isNotEmpty() }
        require(tokens.isNotEmpty()) { "Enter a page range, such as 1-3,5." }
        tokens.forEach { token ->
            if (token.contains('-')) {
                val parts = token.split('-').map { it.trim() }
                require(parts.size == 2) { "Invalid range: $token" }
                val start = parts[0].toIntOrNull()
                    ?: throw IllegalArgumentException("Invalid page number: ${parts[0]}")
                val end = parts[1].toIntOrNull()
                    ?: throw IllegalArgumentException("Invalid page number: ${parts[1]}")
                require(start >= 1 && end >= start && end <= pageCount) {
                    "Range $token must be within 1-$pageCount."
                }
                for (page in start..end) result.add(page - 1)
            } else {
                val page = token.toIntOrNull()
                    ?: throw IllegalArgumentException("Invalid page number: $token")
                require(page in 1..pageCount) { "Page $page is outside 1-$pageCount." }
                result.add(page - 1)
            }
        }
        return result.toList()
    }
}
