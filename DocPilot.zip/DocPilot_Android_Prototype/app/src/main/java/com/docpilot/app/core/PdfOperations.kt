package com.docpilot.app.core

import android.content.Context
import android.net.Uri
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.graphics.image.JPEGFactory
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject
import com.tom_roush.pdfbox.rendering.ImageType
import com.tom_roush.pdfbox.rendering.PDFRenderer
import java.io.File
import java.io.IOException
import kotlin.math.min
import kotlin.math.sqrt

 data class OperationOutput(
    val file: File,
    val suggestedFileName: String,
    val message: String
)

object PdfOperations {
    private const val MAX_RENDER_PIXELS = 8_000_000L

    fun merge(context: Context, uris: List<Uri>): OperationOutput {
        require(uris.size >= 2) { "Select at least two PDF files." }
        val inputs = uris.mapIndexed { index, uri -> copyUriToCache(context, uri, "merge_${index}_", ".pdf") }
        val output = File(context.cacheDir, "docpilot_merged_${System.currentTimeMillis()}.pdf")
        try {
            PDDocument().use { destination ->
                inputs.forEach { file ->
                    PDDocument.load(file).use { source ->
                        PDFMergerUtility().appendDocument(destination, source)
                    }
                }
                require(destination.numberOfPages > 0) { "The selected PDFs contain no pages." }
                destination.save(output)
            }
        } finally {
            inputs.forEach { it.delete() }
        }
        return OperationOutput(output, "DocPilot_Merged.pdf", "Merged ${uris.size} PDFs. Choose where to save the result.")
    }

    fun extractPages(context: Context, uri: Uri, pageRange: String): OperationOutput {
        val input = copyUriToCache(context, uri, "split_source_", ".pdf")
        val output = File(context.cacheDir, "docpilot_pages_${System.currentTimeMillis()}.pdf")
        try {
            PDDocument.load(input).use { source ->
                val selectedPages = PageRangeParser.parse(pageRange, source.numberOfPages)
                PDDocument().use { destination ->
                    selectedPages.forEach { pageIndex ->
                        destination.importPage(source.getPage(pageIndex))
                    }
                    destination.save(output)
                }
            }
        } finally {
            input.delete()
        }
        return OperationOutput(output, "DocPilot_Extracted_Pages.pdf", "Created a PDF with the selected pages. Choose where to save it.")
    }

    fun imagesToPdf(context: Context, uris: List<Uri>): OperationOutput {
        require(uris.isNotEmpty()) { "Select at least one image." }
        val inputs = uris.mapIndexed { index, uri ->
            val extension = when (context.contentResolver.getType(uri)?.lowercase()) {
                "image/png" -> ".png"
                "image/jpeg", "image/jpg" -> ".jpg"
                "image/webp" -> ".webp"
                else -> ".img"
            }
            copyUriToCache(context, uri, "image_${index}_", extension)
        }
        val output = File(context.cacheDir, "docpilot_images_${System.currentTimeMillis()}.pdf")
        try {
            PDDocument().use { document ->
                inputs.forEach { imageFile ->
                    val image = PDImageXObject.createFromFileByContent(imageFile, document)
                    // 96 DPI page sizing preserves the image's aspect ratio.
                    val pageWidth = image.width * 0.75f
                    val pageHeight = image.height * 0.75f
                    val page = PDPage(PDRectangle(pageWidth, pageHeight))
                    document.addPage(page)
                    PDPageContentStream(document, page).use { stream ->
                        stream.drawImage(image, 0f, 0f, pageWidth, pageHeight)
                    }
                }
                document.save(output)
            }
        } finally {
            inputs.forEach { it.delete() }
        }
        return OperationOutput(output, "DocPilot_Images.pdf", "Converted ${uris.size} images into one PDF. Choose where to save it.")
    }

    /**
     * Experimental lossy compression: renders pages to JPEG-backed images.
     * Text selection, links, forms, accessibility tags and vector content are not preserved.
     * The original is never modified. Each pass writes a separate candidate in cache.
     */
    fun compressRasterized(context: Context, uri: Uri, targetBytes: Long): OperationOutput {
        require(targetBytes > 0) { "Target size must be greater than zero." }
        val input = copyUriToCache(context, uri, "compress_source_", ".pdf")
        var bestCandidate: File? = null
        val attempts = listOf(
            144f to 0.78f,
            120f to 0.68f,
            96f to 0.58f,
            72f to 0.48f,
            60f to 0.40f
        )
        try {
            attempts.forEachIndexed { index, (requestedDpi, jpegQuality) ->
                val candidate = File(context.cacheDir, "docpilot_compress_${System.currentTimeMillis()}_$index.pdf")
                PDDocument.load(input).use { source ->
                    PDDocument().use { destination ->
                        val renderer = PDFRenderer(source).apply { isSubsamplingAllowed = true }
                        for (pageIndex in 0 until source.numberOfPages) {
                            val sourcePage = source.getPage(pageIndex)
                            val crop = sourcePage.cropBox
                            val estimatedPixels = (crop.width * requestedDpi / 72f) * (crop.height * requestedDpi / 72f)
                            val safeDpi = if (estimatedPixels > MAX_RENDER_PIXELS) {
                                min(requestedDpi, (requestedDpi * sqrt(MAX_RENDER_PIXELS / estimatedPixels)).coerceAtLeast(36f))
                            } else requestedDpi

                            val bitmap = renderer.renderImageWithDPI(pageIndex, safeDpi, ImageType.RGB)
                            try {
                                val pageWidth = bitmap.width * 72f / safeDpi
                                val pageHeight = bitmap.height * 72f / safeDpi
                                val page = PDPage(PDRectangle(pageWidth, pageHeight))
                                destination.addPage(page)
                                val pdfImage = JPEGFactory.createFromImage(destination, bitmap, jpegQuality)
                                PDPageContentStream(destination, page).use { stream ->
                                    stream.drawImage(pdfImage, 0f, 0f, pageWidth, pageHeight)
                                }
                            } finally {
                                bitmap.recycle()
                            }
                        }
                        destination.save(candidate)
                    }
                }

                if (bestCandidate == null || candidate.length() < bestCandidate!!.length()) {
                    bestCandidate?.delete()
                    bestCandidate = candidate
                } else {
                    candidate.delete()
                }
                if (bestCandidate!!.length() <= targetBytes) return compressionResult(bestCandidate!!, targetBytes)
            }
            val chosen = bestCandidate ?: throw IOException("The PDF could not be compressed.")
            return compressionResult(chosen, targetBytes)
        } finally {
            input.delete()
        }
    }

    private fun compressionResult(file: File, targetBytes: Long): OperationOutput {
        val actual = file.length()
        val targetLabel = formatBytes(targetBytes)
        val actualLabel = formatBytes(actual)
        val detail = if (actual <= targetBytes) {
            "Target reached: $actualLabel (target $targetLabel). Pages were rasterized; review quality before using the result."
        } else {
            "Best result: $actualLabel; target $targetLabel could not be reached with the available quality presets. Review before using."
        }
        return OperationOutput(file, "DocPilot_Compressed.pdf", detail)
    }


    private fun copyUriToCache(context: Context, uri: Uri, prefix: String, suffix: String): File {
        val destination = File.createTempFile(prefix, suffix, context.cacheDir)
        try {
            val input = context.contentResolver.openInputStream(uri)
                ?: throw IOException("Android could not read the selected file.")
            input.use { source -> destination.outputStream().use { target -> source.copyTo(target) } }
            if (destination.length() == 0L) throw IOException("The selected file is empty.")
            return destination
        } catch (error: Exception) {
            destination.delete()
            throw error
        }
    }

    private fun formatBytes(bytes: Long): String = when {
        bytes >= 1024L * 1024L -> "%.2f MB".format(bytes / (1024.0 * 1024.0))
        bytes >= 1024L -> "%.0f KB".format(bytes / 1024.0)
        else -> "$bytes B"
    }
}
