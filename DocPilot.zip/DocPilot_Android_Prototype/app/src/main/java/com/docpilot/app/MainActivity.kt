package com.docpilot.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.docpilot.app.core.OperationOutput
import com.docpilot.app.core.PdfOperations
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private val Ink = Color(0xFF14243A)
private val Muted = Color(0xFF6D7B8D)
private val Teal = Color(0xFF14B8A6)
private val Canvas = Color(0xFFF4F7FB)
private val Line = Color(0xFFE5EAF1)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Teal,
                    onPrimary = Color.White,
                    background = Canvas,
                    surface = Color.White,
                    onSurface = Ink,
                    secondary = Color(0xFF58718D)
                )
            ) {
                DocPilotScreen()
            }
        }
    }
}

private enum class Tool(
    val title: String,
    val subtitle: String,
    val symbol: String,
    val actionLabel: String
) {
    COMPRESS("Compress PDF", "Reduce file size for uploads", "↘", "Choose a PDF"),
    MERGE("Merge PDFs", "Combine documents into one", "＋", "Choose 2 or more PDFs"),
    SPLIT("Extract pages", "Save a page range as a new PDF", "▤", "Choose a PDF"),
    IMAGES("Images to PDF", "Turn selected images into a PDF", "▧", "Choose images")
}

@Composable
private fun DocPilotScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()

    var selectedTool by remember { mutableStateOf<Tool?>(null) }
    var targetMb by remember { mutableStateOf("2") }
    var pageRange by remember { mutableStateOf("1-3") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Select a tool to get started.") }
    var statusIsError by remember { mutableStateOf(false) }
    var showCompressionWarning by remember { mutableStateOf(false) }
    var pendingOutput by remember { mutableStateOf<File?>(null) }

    val createDocument = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { destinationUri ->
        val sourceFile = pendingOutput
        if (destinationUri != null && sourceFile != null) {
            scope.launch {
                busy = true
                try {
                    withContext(Dispatchers.IO) {
                        val output = context.contentResolver.openOutputStream(destinationUri, "w")
                            ?: error("Android could not open the selected save location.")
                        output.use { out ->
                            sourceFile.inputStream().use { input -> input.copyTo(out) }
                        }
                    }
                    status = "Saved successfully. Your original file was not changed."
                    statusIsError = false
                } catch (error: Exception) {
                    status = "Could not save the file: ${error.localizedMessage ?: "Unknown error"}"
                    statusIsError = true
                } finally {
                    sourceFile.delete()
                    pendingOutput = null
                    busy = false
                }
            }
        } else {
            sourceFile?.delete()
            pendingOutput = null
            status = "Save cancelled. The original file was not changed."
            statusIsError = false
        }
    }

    fun processSelection(tool: Tool, uris: List<Uri>) {
        if (uris.isEmpty()) return
        scope.launch {
            busy = true
            status = "Preparing your document on this device…"
            statusIsError = false
            try {
                val result: OperationOutput = withContext(Dispatchers.IO) {
                    when (tool) {
                        Tool.MERGE -> {
                            require(uris.size >= 2) { "Select at least two PDF files to merge." }
                            PdfOperations.merge(context, uris)
                        }
                        Tool.SPLIT -> PdfOperations.extractPages(context, uris.first(), pageRange)
                        Tool.IMAGES -> PdfOperations.imagesToPdf(context, uris)
                        Tool.COMPRESS -> {
                            val mb = targetMb.toDoubleOrNull()
                            require(mb != null && mb > 0.05 && mb <= 100.0) {
                                "Enter a target size between 0.05 MB and 100 MB."
                            }
                            PdfOperations.compressRasterized(context, uris.first(), (mb * 1024 * 1024).toLong())
                        }
                    }
                }
                pendingOutput = result.file
                status = result.message
                statusIsError = false
                createDocument.launch(result.suggestedFileName)
            } catch (error: Exception) {
                status = error.localizedMessage ?: "Something went wrong while processing the file."
                statusIsError = true
            } finally {
                busy = false
            }
        }
    }

    val singlePdfPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> uri?.let { selectedTool?.let { tool -> processSelection(tool, listOf(it)) } } }

    val multiplePdfPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris -> selectedTool?.let { tool -> processSelection(tool, uris) } }

    val imagePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris -> selectedTool?.let { tool -> processSelection(tool, uris) } }

    if (showCompressionWarning) {
        AlertDialog(
            onDismissRequest = { showCompressionWarning = false },
            title = { Text("About this compression mode") },
            text = {
                Text(
                    "The prototype rebuilds each page as a compressed image. This can reduce file size, " +
                        "but selectable text, links, forms and some accessibility information may not be preserved. " +
                        "Your original PDF remains unchanged. Continue only with a copy if those features matter."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showCompressionWarning = false
                    singlePdfPicker.launch(arrayOf("application/pdf"))
                }) { Text("Continue") }
            },
            dismissButton = {
                TextButton(onClick = { showCompressionWarning = false }) { Text("Cancel") }
            }
        )
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Canvas) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { Spacer(Modifier.height(10.dp)) }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("DOCPILOT", color = Teal, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Text("Document tools,
without the hassle.", color = Ink, fontSize = 27.sp, lineHeight = 32.sp, fontWeight = FontWeight.Bold)
                    }
                    Box(
                        modifier = Modifier.size(54.dp).background(Teal, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("D", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            item {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Ink)
                ) {
                    Box(
                        modifier = Modifier.fillMaxWidth().background(
                            Brush.linearGradient(listOf(Color(0xFF16283E), Color(0xFF24475A)))
                        ).padding(20.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("PRIVATE BY DESIGN", color = Color(0xFF75E4D5), fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.4.sp)
                            Text("Get your documents ready to send.", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
                            Text("Choose a file, make the change, and save it back. Your document stays on your device.", color = Color(0xFFD6E1EB), fontSize = 13.sp, lineHeight = 19.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(7.dp).background(Color(0xFF6DE3C8), CircleShape))
                                Text("No account • No upload • No broad storage access", color = Color(0xFFB7F0E7), fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
            item {
                Text("Choose a tool", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ToolCard(Tool.COMPRESS, selectedTool == Tool.COMPRESS, Modifier.weight(1f)) { selectedTool = Tool.COMPRESS }
                        ToolCard(Tool.MERGE, selectedTool == Tool.MERGE, Modifier.weight(1f)) { selectedTool = Tool.MERGE }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ToolCard(Tool.SPLIT, selectedTool == Tool.SPLIT, Modifier.weight(1f)) { selectedTool = Tool.SPLIT }
                        ToolCard(Tool.IMAGES, selectedTool == Tool.IMAGES, Modifier.weight(1f)) { selectedTool = Tool.IMAGES }
                    }
                }
            }
            if (selectedTool != null) {
                item {
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Line)
                    ) {
                        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("${selectedTool!!.symbol}  ${selectedTool!!.title}", color = Ink, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text(selectedTool!!.subtitle, color = Muted, fontSize = 13.sp)
                            when (selectedTool) {
                                Tool.COMPRESS -> OutlinedTextField(
                                    value = targetMb,
                                    onValueChange = { targetMb = it.filter { char -> char.isDigit() || char == '.' }.take(6) },
                                    label = { Text("Target size in MB") },
                                    supportingText = { Text("The result may be larger than the requested limit for some PDFs.") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Tool.SPLIT -> OutlinedTextField(
                                    value = pageRange,
                                    onValueChange = { pageRange = it.filter { char -> char.isDigit() || char == '-' || char == ',' || char == ' ' }.take(40) },
                                    label = { Text("Page range, e.g. 1-3,5") },
                                    supportingText = { Text("Page numbers start at 1. This prototype extracts a range into one PDF.") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                else -> Unit
                            }
                            Button(
                                onClick = {
                                    when (selectedTool) {
                                        Tool.MERGE -> multiplePdfPicker.launch(arrayOf("application/pdf"))
                                        Tool.SPLIT -> singlePdfPicker.launch(arrayOf("application/pdf"))
                                        Tool.IMAGES -> imagePicker.launch(arrayOf("image/*"))
                                        Tool.COMPRESS -> showCompressionWarning = true
                                        null -> Unit
                                    }
                                },
                                enabled = !busy,
                                modifier = Modifier.fillMaxWidth().height(50.dp),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Teal)
                            ) {
                                Text(selectedTool!!.actionLabel, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
            item {
                Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (busy) CircularProgressIndicator(Modifier.size(20.dp), color = Teal, strokeWidth = 2.dp)
                        else Box(Modifier.size(9.dp).background(if (statusIsError) Color(0xFFD95C5C) else Teal, CircleShape))
                        Column(Modifier.weight(1f)) {
                            Text(if (busy) "Working" else "Status", color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text(status, color = if (statusIsError) Color(0xFFB63838) else Muted, fontSize = 12.sp, lineHeight = 17.sp)
                        }
                    }
                }
            }
            item {
                Text(
                    "Prototype build • Local processing • Original files are never overwritten",
                    color = Muted,
                    fontSize = 11.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 20.dp)
                )
            }
        }
    }
}

@Composable
private fun ToolCard(tool: Tool, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = modifier.height(132.dp),
        shape = RoundedCornerShape(19.dp),
        colors = CardDefaults.cardColors(containerColor = if (selected) Color(0xFFE7FAF7) else Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) Teal else Line),
        elevation = CardDefaults.cardElevation(defaultElevation = if (selected) 2.dp else 0.dp)
    ) {
        Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Text(tool.symbol, fontSize = 23.sp, color = Teal, fontWeight = FontWeight.Bold)
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(tool.title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(tool.subtitle, color = Muted, fontSize = 11.sp, lineHeight = 14.sp)
            }
        }
    }
}
