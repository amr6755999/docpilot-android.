# Build notes for Windows

The source archive intentionally omits `gradle-wrapper.jar` because the build container could not fetch the Gradle distribution or wrapper artifact. The project itself contains the exact Gradle version configuration in this note.

## Option A — Android Studio

1. Install Android Studio and JDK 17.
2. Install Android SDK Platform 36 from SDK Manager.
3. Install Gradle 8.13 locally, or let Android Studio configure Gradle when opening the project.
4. In **File > Settings > Build, Execution, Deployment > Build Tools > Gradle**, set Gradle JDK to Embedded JDK 17 and select the local Gradle 8.13 installation if Android Studio asks for one.
5. Sync and run.

## Option B — PowerShell build script

From the project folder, run PowerShell and execute:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\build-windows.ps1
```

The script downloads Gradle 8.13 if needed, detects the usual Android SDK path, and runs `:app:assembleDebug`. If Android SDK Platform 36 or Build Tools 36 are missing, install them from Android Studio SDK Manager first.

## Option C — Gradle command line

Install Gradle 8.13 and add its `bin` directory to PATH. From the project root run:

```powershell
gradle --version
gradle :app:assembleDebug
gradle :app:testDebugUnitTest
```

The debug APK, if the build succeeds, will be at:

`app/build/outputs/apk/debug/app-debug.apk`
