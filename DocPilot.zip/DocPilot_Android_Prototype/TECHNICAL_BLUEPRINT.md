# DocPilot — Technical Development Blueprint

## Product goal

A local-first Android utility that prepares user-selected documents for upload and sharing. It should avoid broad storage permissions and should never silently overwrite originals.

## MVP workflows

| Workflow | Input | Output | Implementation |
|---|---|---|---|
| Merge | 2+ selected PDFs | One PDF | PDFMergerUtility.appendDocument |
| Extract pages | One PDF + page expression | One PDF | PDDocument.importPage |
| Images to PDF | Selected image files | One PDF | PDImageXObject + PDPageContentStream |
| Compress (prototype only) | One PDF + target bytes | One rasterized PDF candidate | PDFRenderer + JPEGFactory |

## Android architecture

- UI: Kotlin + Jetpack Compose Material 3.
- File selection: ActivityResultContracts.OpenDocument / OpenMultipleDocuments.
- File export: ActivityResultContracts.CreateDocument.
- Processing: Kotlin coroutines on Dispatchers.IO.
- PDF engine: PDFBox-Android 2.0.27.0.
- No storage permission declarations in AndroidManifest.
- No network calls in the first prototype.

## Important design constraints

1. All operations work on copies in app cache.
2. The original input is never overwritten.
3. Compression must show a warning and user consent because current prototype rasterizes pages.
4. A target size is a best-effort goal, not a guarantee.
5. For large documents, page rendering must cap the pixel area to limit memory use.
6. Export always goes through Android's system document picker.

## Before production

- Replace rasterized compression with a document-preserving optimizer where possible.
- Add file-size split using a user-selected output folder, with a clear per-part size report.
- Add page preview / page order editing.
- Add structured error handling for encrypted, malformed, signed, and unusually large PDFs.
- Add instrumentation tests across Android 10–16 and multiple OEM devices.
- Verify PDF rendering/encoding quality on scanned, vector, mixed, rotated, and annotated documents.
- Add privacy policy and data safety declarations only after confirming final SDK behavior.
- Add AdMob and Play Billing only after product validation.

## Release baseline

- compileSdk 36 / targetSdk 36.
- minSdk 24.
- AGP 8.13.2, Gradle 8.13, Kotlin 2.3.21, Compose BOM 2026.09.00.
- Java target 17.
